<?php
// get_schedules.php
// Place this script in the same directory as your exported JSON schedule files on cvcc.edu.

header('Content-Type: application/json'); // Ensure the browser knows the response is JSON

// --- IMPORTANT: CORS HEADERS ARE NOT NEEDED AND SHOULD NOT BE PRESENT FOR SAME-ORIGIN REQUESTS ---
// If you previously added Access-Control-Allow-Origin headers, please ensure they are NOT in this file.

$files_data = [];
// Set your local timezone (e.g., 'America/New_York' for Eastern Daylight Time/EDT in Hickory, NC)
$timezone = new DateTimeZone('America/New_York'); 

foreach (glob("*.json") as $filename) {
    // Optionally, add logic here to exclude certain JSON files if they're not schedules.
    // For example, if this script itself accidentally gets a .json extension.
    // For now, it lists all .json files found.

    $file_path = $filename; // Path to the JSON file relative to this script

    // Get the last modification time of the file
    $timestamp = filemtime($file_path);

    // Format the timestamp for display
    $dt = new DateTime("@$timestamp");
    $dt->setTimezone($timezone); // Apply the defined timezone
    $formatted_time = $dt->format('m-d-Y h:i A'); // Format as MM-DD-YYYY HH:MM AM/PM

    // **** CRITICAL CHANGE: Return an object for each file, not just the filename string ****
    $files_data[] = [
        'filename' => $filename,
        'lastModified' => $formatted_time
    ];
}

// Output the array of file data (filename and last modified time) as JSON
echo json_encode(array_values($files_data)); // array_values ensures it's a simple sequential array
?>